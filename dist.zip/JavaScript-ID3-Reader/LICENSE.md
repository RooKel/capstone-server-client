Copyright (c) 2008 Jacob Seidelin, http://blog.nihilogic.dk/
[BSD License](http://opensource.org/licenses/BSD-3-Clause)

Copyright (c) 2009 Opera Software ASA
[BSD License](http://dev.opera.com/licenses/bsd/)

Copyright (c) 2010 António Afonso
[BSD License](http://opensource.org/licenses/BSD-3-Clause)

Copyright (c) 2010 Joshua Kifer
[BSD License](http://opensource.org/licenses/BSD-3-Clause)